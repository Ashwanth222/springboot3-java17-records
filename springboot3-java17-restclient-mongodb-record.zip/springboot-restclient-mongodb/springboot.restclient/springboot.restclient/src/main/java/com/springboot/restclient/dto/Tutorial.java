package com.springboot.restclient.dto;


public record Tutorial(String id,String title, String description, boolean published) { }

